edit src\app\_services\adal-config.service.ts with your ADFS server name

ADFS config URL

https://docs.microsoft.com/en-us/windows-server/identity/ad-fs/development/enabling-oauth-confidential-clients-with-ad-fs