export const environment = {
  production: true,
  envName: 'prod',
  apiServerUrl: 'http://localhost:44008'
};
