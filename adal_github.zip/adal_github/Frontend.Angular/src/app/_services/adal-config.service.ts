import { Injectable } from '@angular/core';

@Injectable()
export class AdalConfigService {
  public get adalConfig(): any {
    return {
      instance: 'https://YOURADFSSERVERNAME/',
      tenant: 'adfs', // Enpoints -> OAuth 2.0 Authorization Endpoint: https://login.windows.net/{tenant}/oauth2
      clientId: 'CLIENT_ID', // Application ID
      redirectUri: window.location.origin + '/auth-callback',
      
      postLogoutRedirectUri: window.location.origin + '/auth-callback'
    };
  }
}
